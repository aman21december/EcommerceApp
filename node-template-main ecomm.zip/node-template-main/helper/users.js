module.exports = {
  USER: "user",
  ADMIN: "admin",
};
