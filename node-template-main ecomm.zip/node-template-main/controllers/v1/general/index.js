const { createApi } = require("../index");
module.exports = { createApi };
