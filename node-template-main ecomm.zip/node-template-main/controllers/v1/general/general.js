const sequelize = require("../../../config/db");

const createApi = async (req, res, next) => {
  try {
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createApi,
};
