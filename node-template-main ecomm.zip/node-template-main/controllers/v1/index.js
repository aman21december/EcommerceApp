const { createApi } = require("./general");

module.exports = {
  createApi,
};
