const SPACES_KEY = "6QHNARTMC5FUPDCFFXP6";
const SPACES_SECRET = "BQRGb0fcCa6ExNSE5I83jyHZBWpzWSGyAF4TTgGISWg";
const BUCKET_NAME = "upload-assets";
const SPACE_END_POINT = "sgp1.digitaloceanspaces.com";

module.exports = {
	SPACES_KEY,
	SPACES_SECRET,
	BUCKET_NAME,
	SPACE_END_POINT,
};
