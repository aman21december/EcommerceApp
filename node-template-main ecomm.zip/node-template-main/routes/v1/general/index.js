const general = require("./general");

module.exports = {
  general,
};
